package com.Notification_demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Notification_demo.model.Notification;
import com.Notification_demo.repository.NotificationRepository;

@RestController
@RequestMapping("/notifications")
//@CrossOrigin(origins = "http://localhost:5173")
public class NotificationController {

	@Autowired
	private NotificationRepository notificationRepo;

	@PostMapping("/save")
	public Notification save(@RequestBody Notification notification)
	{
		return notificationRepo.save(notification);
	}

	@GetMapping("/getAllnotification")
	public List<Notification> getAll() {
		return notificationRepo.findAll();
	}

	@GetMapping("/getnotify/{userId}")
	public List<Notification> getNotifications(@PathVariable String userId) {
 
		return notificationRepo.findByUserId(userId);
	}
}