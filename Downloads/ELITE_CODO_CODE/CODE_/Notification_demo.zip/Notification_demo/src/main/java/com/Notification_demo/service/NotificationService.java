package com.Notification_demo.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.Notification_demo.model.Notification;
import com.Notification_demo.repository.NotificationRepository;

@Service
public class NotificationService {

	@Autowired
	private NotificationRepository repository;

	@Autowired
	private SimpMessagingTemplate messagingTemplate;

	public void createNotification(String id, String title, String message) {

		Notification notification =
				new Notification(id, title, message, message, message, false, null);

		notification.setId(id);
		notification.setTitle(title);
		notification.setMessage(message);
		notification.setRead(false);
		notification.setCreatedAt(LocalDateTime.now());

		// Save to MongoDB
		repository.save(notification);

		// Send notification through WebSocket
		messagingTemplate.convertAndSend(
				"/topic/notifications",
				notification
				);
	}

}
