package com.Notification_demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.Notification_demo.model.Notification;

@Repository
public interface NotificationRepository extends MongoRepository<Notification, String> {

	List<Notification> findByUserId(String id);
	long countByUserIdAndReadFalse(String id);
}