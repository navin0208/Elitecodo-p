//package com.Notification_demo.runner;
//
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//import com.Notification_demo.repository.UserRepository;
//
//@Component
//public class MongoTestRunner implements CommandLineRunner {
//
//    private final UserRepository userRepository;
//
//    public MongoTestRunner(UserRepository userRepository) {
//        this.userRepository = userRepository;
//    }
//
//    @Override
//    public void run(String... args) {
//        System.out.println("MongoDB Connected Successfully");
//        System.out.println("Documents Count: " + userRepository.count());
//    }
//}