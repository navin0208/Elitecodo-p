package com.Notification_demo.model;

import java.time.LocalDateTime;

import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@EntityScan
@Document(collection = "notification")
public class Notification {

	@Id
	private String id;
	private String title;
	private String message;
	private String type;
	private String userId;
	private boolean read;
	private LocalDateTime createdAt;

	// Default Constructor
	public Notification() {
		this.createdAt = LocalDateTime.now();
	}
	
	public Notification(String id, String title, String message, String type, String userId, boolean read,
			LocalDateTime createdAt) {
		super();
		this.id = id;
		this.title = title;
		this.message = message;
		this.type = type;
		this.userId = userId;
		this.read = read;
		this.createdAt = createdAt;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean isRead() {
		return read;
	}

	public void setRead(boolean read) {
		this.read = read;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
}
