package com.Notification_demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Notification_demo.service.NotificationService;
//
//@RestController
//@RequestMapping("/api")
//public class RegistrationController {
//
//    @Autowired
//    private NotificationService service;
//
//    @PostMapping("/register")
//    public String register() {
//        service.createNotification("1", "Email Sent","Verification email sent");
//        return "success";
//    }
//
//    @PostMapping("/verify")
//    public String verify() {
//    	service.createNotification("1","Email Verified","Email verified successfully");
//        return "verified";
//    }
//
//    @PostMapping("/complete")
//    public String complete() {
//        service.createNotification("1","Registration Complete","Registration completed successfully");
//        return "done";
//    }
//}

@RestController
@RequestMapping("/api")
public class RegistrationController {

    @Autowired
    private NotificationService service;

    @PostMapping("/register")
    public String register() {

        service.createNotification(
                "1",
                "Email Sent",
                "Verification email sent"
        );

        return "success";
    }

    @PostMapping("/verify")
    public String verify() {

        service.createNotification(
                "1",
                "Email Verified",
                "Email verified successfully"
        );

        return "verified";
    }

    @PostMapping("/complete")
    public String complete() {

        service.createNotification(
                "1",
                "Registration Complete",
                "Registration completed successfully"
        );

        return "done";
    }
}