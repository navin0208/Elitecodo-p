package com.Notification_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotificationDemoApplication.class, args);
		System.out.println("Welcome to notification demo project");
	}
}
