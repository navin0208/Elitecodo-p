export const MainURL = {
  HostURL: 'http://192.168.0.199:8583/',
  // HostURL: 'http://10.74.154.165:8583/',
  // HostURL: 'http://192.168.0.105:8583/',
      // HostURL: 'http://192.168.1.102:8583/',
  // HostURL: 'https://elitecodo.com/',   

  /////////
  ReactWeb: 'https://teacher.elitecodo.com',
};

