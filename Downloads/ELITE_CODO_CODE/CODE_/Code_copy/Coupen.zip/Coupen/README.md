## ZPlus Coupen Generator



## Software Requirements

* Spring Tool Suite (STS)
* Mongo DB (Installation + Compass)
* Git
* Postman
* Internet connection

---

## Technologies Used

* Java
* Spring Boot
* REST API
* Spring Data JPA
* MongoDB
* Maven

---

## Database Used

* MongoDB

> **Note:** Database creation scripts will be added later in this README file.

---

## DataBase Structure: 

* Coupen_Master
* Coupen_Type

---

## REST APIs Usage for Testing (Postman)

All REST APIs in this project are **intended for testing purposes using Postman**. Postman allows sending HTTP requests, passing input values through URLs, and verifying responses without the need for a frontend application.

### Available REST API

1. **Save Coupon Type Data**

   ```
   [http://localhost:8080/save](http://localhost:8080/savedcoupontype)
   ```

2. **View Coupen Type Data**

   ```
   [http://localhost:8080/viewdata](http://localhost:8080/viewcoupontype)
   ```

3. **Save Coupon**
   ```
   http://localhost:8080/savecoupen
   ```

4. **View All Coupons**

   ```
   [http://localhost:8080/searchById/{id](http://localhost:8080/allcoupen)}
   ```
---

## Common Errors & Fixes

| Error                      | Solution                     |
| -------------------------- | ---------------------------- |
| Java version mismatch      | Set correct JDK in STS       |
| Maven dependency error     | Run `Maven → Update Project` |
| Port already in use        | Change server port           |
| Database connection failed | Check DB credentials         |
| CORS Error                 | Write url in controller from react |


---

## Learning Outcomes

* Understanding Spring Boot REST API development
* Practicing CRUD operations
* Using Postman for API testing
* Handling path variables and request mappings
* Implementing search and filter operations

---

## Suggestions & Improvements

Suggestions and project improvements are always welcome!

---

## Acknowledgment

Thanks a lot
