package zplus.Coupen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoupenApplicationTests {

	@Test
	void contextLoads() {
	}
}