package zplus.Coupon.service;

import java.util.List;

import zplus.Coupon.Entity.Coupon_Master;

public interface Coupon_Service {

	boolean createCoupon(Coupon_Master coupon_master);
	List<Coupon_Master> getAllCoupons();
}