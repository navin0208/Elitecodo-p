//package zplus.Coupon.serviceImpl;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import zplus.Coupon.Entity.Coupon;
//import zplus.Coupon.repository.MasterCouponRepository;
//import zplus.Coupon.service.MasterCouponService;
//
//@Service
//public class MasterCouponServiceImpl implements MasterCouponService {
//
//	@Autowired
//	MasterCouponRepository couponrepository;
//	
//	@Override
//	public boolean insertCoupon(Coupon coupon) {
//		try
//		{
//			couponrepository.insert(coupon);
//			return true;
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//			return false;
//		}
//	}
//
//	@Override
//	public List<Coupon> getcoupons() {
//		// TODO Auto-generated method stub
//		return couponrepository.findAll();
//	}
//
//}
