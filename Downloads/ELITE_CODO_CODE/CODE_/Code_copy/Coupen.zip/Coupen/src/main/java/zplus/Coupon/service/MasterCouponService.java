//package zplus.Coupon.service;
//
//import java.util.List;
//
//import zplus.Coupon.Entity.Coupon;
//
//public interface MasterCouponService {
//	
//	public boolean insertCoupon(Coupon coupon);
//	List<Coupon> getcoupons();
//}
