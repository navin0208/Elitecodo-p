package zplus.Coupon.serviceImpl;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import zplus.Coupon.Entity.Coupon_Master;
import zplus.Coupon.repository.CouponType_Repository;
import zplus.Coupon.repository.Coupon_Repository;
import zplus.Coupon.repository.UserCouponRepository;
import zplus.Coupon.service.Coupon_Service;

@Service
public class CouponServiceImpl implements Coupon_Service {

    @Autowired
    private Coupon_Repository coupon_Repository;
    
	@Override
	public boolean createCoupon(Coupon_Master coupon_master) {
		try {
			coupon_Repository.insert(coupon_master);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<Coupon_Master> getAllCoupons() {
		return coupon_Repository.findAll();
	}
    
 
}