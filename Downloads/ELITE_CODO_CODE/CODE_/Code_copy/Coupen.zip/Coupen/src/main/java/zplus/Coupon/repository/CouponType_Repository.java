package zplus.Coupon.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import zplus.Coupon.Entity.Coupon_Type;

public interface CouponType_Repository extends MongoRepository<Coupon_Type,String> {
	 Optional<Coupon_Type> findById(String couponTypeId);

}