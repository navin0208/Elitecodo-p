//package zplus.Coupon.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import zplus.Coupon.Entity.Coupon;
//import zplus.Coupon.service.MasterCouponService;
//
//@RestController
//public class MasterCouponController {
//	
//	@Autowired
//	MasterCouponService mastercouponservice;
//	
//	@PostMapping("store-coupon")
//	public String saveCoupon(@RequestBody Coupon coupon)
//	{
//		boolean b = mastercouponservice.insertCoupon(coupon);
//		
//		if(b)
//		{
//			return "Coupon Saved Successfully";
//		}
//		else
//		{
//			return "Problem occurs in saved Coupon";
//		}
//	}
//	
//	@GetMapping("view-coupon")
//	public List<Coupon> AllCoupons()
//	{
//		return mastercouponservice.getcoupons();
//	}
//	
//	
//}
