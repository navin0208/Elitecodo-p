package zplus.Coupon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import zplus.Coupon.Entity.UserCoupon;
import zplus.Coupon.service.UserService;

@RestController
public class UserController {
	
	@Autowired 
	UserService userservice;
	
	@PostMapping("/save-user")
	public String saveUser(@RequestBody UserCoupon usercoupon)
	{
		boolean b = userservice.createUser(usercoupon);
		if(b)
		{
			return "User saved Successfully";
		}
		else
		{
			return "Problem Occurs in saved data in database";
		}
	}
}