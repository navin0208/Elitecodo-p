//package zplus.Coupon.Entity;
//
//import java.util.Date;
//
//import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;
//
//@Document(collation = "couponDemo")
//public class Coupon {
//	
//    @Id
//    private String couponId;
//    private String coupon;
//    private String description;
//    private String CouponType;
//    private Date expiryDate;
//    private Status status;
//    
//    public enum Status {
//        ACTIVE,
//        INACTIVE,
//        EXPIRED
//    }
//    
//	public Coupon() {
//		super();
//	}
//
//	
//
//	public String getCouponId() {
//		return couponId;
//	}
//
//
//
//	public void setCouponId(String couponId) {
//		this.couponId = couponId;
//	}
//
//
//
//	public String getCoupon() {
//		return coupon;
//	}
//
//
//
//	public void setCoupon(String coupon) {
//		this.coupon = coupon;
//	}
//
//
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	public String getCouponType() {
//		return CouponType;
//	}
//
//	public void setCouponType(String couponType) {
//		CouponType = couponType;
//	}
//
//	public Date getExpiryDate() {
//		return expiryDate;
//	}
//
//	public void setExpiryDate(Date expiryDate) {
//		this.expiryDate = expiryDate;
//	}
//
//	public Status getStatus() {
//		return status;
//	}
//
//	public void setStatus(Status status) {
//		this.status = status;
//	}  
//}