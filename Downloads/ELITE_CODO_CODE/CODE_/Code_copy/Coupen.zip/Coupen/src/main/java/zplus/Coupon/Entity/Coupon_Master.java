package zplus.Coupon.Entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "coupon_master")
public class Coupon_Master {

    @Id
    private String coupenId;
    private String coupen;
    private Date expiryDate;
    private Status status;

    @DBRef
    private Coupon_Type couponTypeId;
    
    public enum Status {
        ACTIVE,
        INACTIVE,
        EXPIRED
    }


	public String getCoupenId() {
		return coupenId;
	}


	public void setCoupenId(String coupenId) {
		this.coupenId = coupenId;
	}


	public String getCoupen() {
		return coupen;
	}


	public void setCoupen(String coupen) {
		this.coupen = coupen;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public Coupon_Type getCouponTypeId() {
		return couponTypeId;
	}


	public void setCouponTypeId(Coupon_Type couponTypeId) {
		this.couponTypeId = couponTypeId;
	}	
}