package zplus.Coupon.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import zplus.Coupon.Entity.UserCoupon;

@Repository
public interface UserCouponRepository extends MongoRepository<UserCoupon, String> {

}