package zplus.Coupon.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import zplus.Coupon.Entity.Coupon_Master;

@Repository
public interface Coupon_Repository extends MongoRepository<Coupon_Master, String>{
	
}