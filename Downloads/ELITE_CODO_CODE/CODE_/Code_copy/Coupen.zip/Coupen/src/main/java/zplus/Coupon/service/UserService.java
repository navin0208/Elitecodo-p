package zplus.Coupon.service;

import zplus.Coupon.Entity.UserCoupon;

public interface UserService{
	public boolean createUser(UserCoupon usercoupon);
}
