//package zplus.Coupon.repository;
//
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.stereotype.Repository;
//
//import zplus.Coupon.Entity.Coupon;
//
//@Repository
//public interface MasterCouponRepository extends MongoRepository<Coupon, String>{
//
//}