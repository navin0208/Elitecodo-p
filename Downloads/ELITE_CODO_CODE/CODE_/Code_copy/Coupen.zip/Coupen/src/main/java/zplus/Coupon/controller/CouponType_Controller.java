package zplus.Coupon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import zplus.Coupon.Entity.Coupon_Type;
import zplus.Coupon.service.CouponType_Service;


@RestController
public class CouponType_Controller {
	
	@Autowired
	CouponType_Service typeService;
	
	@PostMapping("/coupon-types")
	public String saveType(@RequestBody Coupon_Type couponType)
	{
		boolean b = typeService.InsertType(couponType);
		if(b)
		{
			return "Coupon Type Saved SuccessFully";
		}
		else
		{
			return "Problem Occurs in save Type Data";
		}
	}
	
	@GetMapping("/type-list")
	public List<Coupon_Type> getAllCoupons()
	{
		return typeService.ViewAllTypes();
	}
}