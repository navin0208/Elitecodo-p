package zplus.Coupon.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import zplus.Coupon.Entity.UserCoupon;
import zplus.Coupon.repository.UserCouponRepository;
import zplus.Coupon.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserCouponRepository userrepository;

	@Override
	public boolean createUser(UserCoupon usercoupon) {
		
	try {
			userrepository.insert(usercoupon);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
	}
}