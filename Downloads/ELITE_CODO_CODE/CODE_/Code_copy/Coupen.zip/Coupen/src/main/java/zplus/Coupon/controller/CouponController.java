package zplus.Coupon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import zplus.Coupon.Entity.Coupon_Master;
import zplus.Coupon.service.Coupon_Service;

@RestController
public class CouponController {
	
	@Autowired
	Coupon_Service couponservice;
	
	@PostMapping("/save-coupon")
	public String saveCoupen(@RequestBody Coupon_Master couponMaster)
	{		
		boolean b= couponservice.createCoupon(couponMaster);
		if(b)
		{
			return "Coupon Saved Successfully";
		}
		else
		{
			return "Problem Occurs in saved data in database";
		}
	}
	
	@GetMapping("/view-coupon")
	public List<Coupon_Master> getAllCoupon()
	{
		return couponservice.getAllCoupons();
	}
}