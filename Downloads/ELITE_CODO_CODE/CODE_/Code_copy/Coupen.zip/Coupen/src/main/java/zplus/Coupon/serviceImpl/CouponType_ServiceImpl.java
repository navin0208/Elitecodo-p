package zplus.Coupon.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import zplus.Coupon.Entity.Coupon_Type;
import zplus.Coupon.repository.CouponType_Repository;
import zplus.Coupon.service.CouponType_Service;

@Service
public class CouponType_ServiceImpl implements CouponType_Service {

	@Autowired
	CouponType_Repository couponType_repository;

	@Override
	public List<Coupon_Type> ViewAllTypes() {
		return couponType_repository.findAll();
	}

	@Override
	public boolean InsertType(Coupon_Type couponType) {
	    try {
	        couponType_repository.save(couponType);
	        return true;
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        return false;
	    }
	}
}