package zplus.Coupon.Entity;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "coupon_type")
public class Coupon_Type {
	@Id
	private String couponTypeId;
	private String couponType;
	
	public Coupon_Type() {
		super();
	}
	public Coupon_Type(String couponTypeId, String couponType) {
		super();
		this.couponTypeId = couponTypeId;
		this.couponType = couponType;
	}
	public String getCouponTypeId() {
		return couponTypeId;
	}
	public void setCouponTypeId(String couponTypeId) {
		this.couponTypeId = couponTypeId;
	}
	public String getCouponType() {
		return couponType;
	}
	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}
}