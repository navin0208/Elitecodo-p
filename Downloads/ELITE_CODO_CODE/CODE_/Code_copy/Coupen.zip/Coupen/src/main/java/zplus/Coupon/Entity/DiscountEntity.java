package zplus.Coupon.Entity;

import java.math.BigDecimal;

public class DiscountEntity {

	private String discountId;
	
	private String discountType;
	
	private BigDecimal discountPercent;
	
	private BigDecimal discountAmount;
	

}
