package zplus.Coupon.service;

import java.util.List;

import zplus.Coupon.Entity.Coupon_Type;

public interface CouponType_Service {
	public boolean InsertType(Coupon_Type couponType);

	List<Coupon_Type> ViewAllTypes();
}