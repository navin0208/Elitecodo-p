package zplus.Coupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoupenApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoupenApplication.class, args);
		System.out.println("Welcome, to my Coupon Management Project.");
	}

}
